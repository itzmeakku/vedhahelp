/// <reference path="globals/async/index.d.ts" />
/// <reference path="globals/node/index.d.ts" />
