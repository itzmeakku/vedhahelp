﻿var mysql = require('mysql');

var connection = function () {
    this.pool = mysql.createPool({
        host: 'localhost',
        user: 'root',
        database: 'location',
        connectionLimit: 100
    });
    this.db_call = function (callback) {
        this.pool.getConnection(function (err, connection) {
            if (err)
                console.log("ERROR IN CONNECTION " + err);
            else {
                callback(connection);
            }
        });
    };
};

module.exports = new connection();