﻿var pool = require("../DB/connection");


exports.getNotification = function (req, res, next) {
    pool.db_call(function (connection) {
        connection.query('select n.ID, n.UID, n.SENSORID, n.MESSAGE , s.SENSORVALUE \
            from notification n, sensor s\
            where n.SENSORID = s.SENSORID\
            and n.UID = ?', [req.params.UID], function (error, results, fields) {
            if (error) {
                console.log('Error --> ' + error);
                res.send({ status: 0, message: "Error in Loading sensor data" });
                connection.release();
                return;
            }
            res.send({ status: 1, body: results });
            connection.release();
        });
    });
};

exports.addNotification = function (req, res, next) {
    pool.db_call(function (connection) {
        connection.query(' Insert into notification set ?', [req.body], function (error, results, fields) {
            if (error) {               
                console.log('Error --> ' + error);
                res.send({ status: 0, message: "Error in adding Notification data" });
                connection.release();
                return;
            }
            res.send({ status: 1, message: "Notification data added successfully" });
            connection.release();
        });
    });
};
exports.updateNotification = function (req, res, next) {
    pool.db_call(function (connection) {
        connection.query('update notification set ? where ID = ?', [req.body, req.params.ID], function (error, results, fields) {
            if (error) {
                console.log('Error --> ' + error);
                res.send({ status: 0, message: "Error in updating Notification data" });
                connection.release();
                return;
            }
            res.send({ status: 1, message: "Notification data updated successfully" });
            connection.release();
        });
    });
};
exports.deleteNotification = function (req, res, next) {
    pool.db_call(function (connection) {
        connection.query('delete from notification where ID = ? ', [req.params.ID], function (error, results, fields) {
            if (error) {
                console.log('Error --> ' + error);
                res.send({ status: 0, message: "Error in Deleting Notification data" });
                connection.release();
                return;
            }
            res.send({ status: 1, message: "Notification data deleted successfully" });
            connection.release();
        });
    });
};