﻿var pool = require("../DB/connection");


exports.getMessage = function (req, res, next) {   
        pool.db_call(function (connection) {
            connection.query('Select * from message where UID = ? order by UPDATE_TS desc;', [req.params.UID], function (error, results, fields) {
                if (error) {
                    console.log('Error --> ' + error);
                    res.send({ status: 0, message: "Error in loading Message data" });
                    connection.release();
                    return;
                }
                res.send({ status: 1, body: results });
                connection.release();
            });
        });    
};

exports.addMessage = function (req, res, next) {
    pool.db_call(function (connection) {
        connection.query(' Insert into message set ?', [req.body], function (error, results, fields) {
            if (error) {
                console.log('Error --> ' + error);
                res.send({ status: 0, message: "Error in adding Message data" });
                connection.release();
                return;
            }
            res.send({ status: 1, message: "Message data added successfully" });
            connection.release();
        });
    });
};
exports.updateMessage = function (req, res, next) {
    pool.db_call(function (connection) {
        connection.query('update message set ? where ID = ?', [req.body, req.params.ID], function (error, results, fields) {
            if (error) {
                console.log('Error --> ' + error);
                res.send({ status: 0, message: "Error in updating Message data" });
                connection.release();
                return;
            }
            res.send({ status: 1, message: "Message data updated successfully" });
            connection.release();
        });
    });
};
exports.deleteMessage = function (req, res, next) {
    pool.db_call(function (connection) {
        connection.query('delete from message where ID = ? ', [req.params.ID], function (error, results, fields) {
            if (error) {
                console.log('Error --> ' + error);
                res.send({ status: 0, message: "Error in Deleting Message data" });
                connection.release();
                return;
            }
            res.send({ status: 1, message: "Message data deleted successfully" });
            connection.release();
        });
    });
};