﻿var user = require("../controller/user");
var location = require("../controller/location");
var message = require("../controller/message");
var notification = require("../controller/notification");
var sensor = require("../controller/sensor");


module.exports = function (app) {

    //User
    app.post("/api/register", user.register);
    app.post("/api/login", user.login);
    app.put("/api/user/:UID", user.updateUser);
    app.get("/api/user/:UID", user.getUser);

    //Location
    app.post("/api/location", location.addLocation);
    app.put("/api/location/:ID", location.updateLocation);
    app.get("/api/location/:UID", location.getLocation);
    app.delete("/api/location/:ID", location.deleteLocation);

    //Sensor
    app.get("/api/sensor", sensor.getAllSensors);
    app.post("/api/sensor", sensor.addSensor);
    app.put("/api/sensor/:ID", sensor.updateSensor);
    app.get("/api/sensor/:ID", sensor.getSensor);
    app.delete("/api/sensor/:ID", sensor.deleteSensor);

    //Notification
    app.get("/api/notification/:UID", notification.getNotification);
    app.post("/api/notification", notification.addNotification);
    app.put("/api/notification/:ID", notification.updateNotification);
    app.delete("/api/notification/:ID", notification.deleteNotification);


    //Message
    app.get("/api/message/:UID", message.getMessage);
    app.post("/api/message", message.addMessage);
    app.put("/api/message/:ID", message.updateMessage);
    app.delete("/api/message/:ID", message.deleteMessage);
};