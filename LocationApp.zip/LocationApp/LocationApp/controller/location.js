﻿var pool = require("../DB/connection");

exports.addLocation = function (req, res, next) {
    pool.db_call(function (connection) {
        connection.query(' Insert into location set ?', [req.body], function (error, results, fields) {
            if (error) {
                console.log('Error --> ' + error);
                res.send({ status: 0, message: "Error in adding Location data" });
                connection.release();
                return;
            }
            res.send({ status: 1, message: "Location data added successfully" });
            connection.release();
        });
    });
};
exports.updateLocation = function (req, res, next) {
    pool.db_call(function (connection) {
        connection.query('update location set ? where ID = ?', [req.body, req.params.ID], function (error, results, fields) {
            if (error) {
                console.log('Error --> ' + error);
                res.send({ status: 0, message: "Error in updating Location data" });
                connection.release();
                return;
            }
            res.send({ status: 1, message: "Location data updated successfully" });
            connection.release();
        });
    });
};
exports.getLocation = function (req, res, next) {
    pool.db_call(function (connection) {
        connection.query('Select * from location where UID = ? order by UPDATE_TS desc;', [req.params.UID], function (error, results, fields) {
            if (error) {
                console.log('Error --> ' + error);
                res.send({ status: 0, message: "Error in loading location data" });
                connection.release();
                return;
            }
            res.send({ status: 1, body: results });
            connection.release();
        });
    });
};
exports.deleteLocation = function (req, res, next) {
    pool.db_call(function (connection) {
        connection.query('delete from location where ID = ? ', [req.params.ID], function (error, results, fields) {
            if (error) {
                console.log('Error --> ' + error);
                res.send({ status: 0, message: "Error in Deleting location data" });
                connection.release();
                return;
            }
            res.send({ status: 1, message: "Location data deleted successfully"});
            connection.release();
        });
    });
};