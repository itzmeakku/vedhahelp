﻿var pool = require("../DB/connection");

exports.register = function (req, res, next) {
    pool.db_call(function (connection) {
        connection.query('Insert into user set ? ', [req.body], function (error, results, fields) {
            if (error) {
                if (error.code == 'ER_DUP_ENTRY') {
                    res.send({ status: 0, message: "Username already exists" });
                    connection.release();
                    return;                   
                }
                console.log('Error --> ' + error);
                res.send({ status: 0, message: "Error in Registration" });
                connection.release();
                return;
                }
                res.send({ status: 1, message: "Registration success" });                   
                connection.release();
            });
    });
};

exports.login = function (req, res, next) {
    pool.db_call(function (connection) {
        connection.query('Select UID, PASSWORD from user where USERNAME = ?', [req.body.username], function (error, results, fields) {
            if (error) {               
                console.log('Error --> ' + error);
                res.send({ status: 0, message: "Error in Login" });
                connection.release();
                return;
            }
            if (!results.length)
                res.send({ status: 0, message: "No such user exists" });
            else {
                if (req.body.password == results[0].PASSWORD)
                    res.send({ status: 1, message: "Login success...", UID: results[0].UID });
                else
                    res.send({ status: 0, message: "Incorrect Passowrd..." });
            }
            connection.release();         
        });
    });  
};

exports.updateUser = function (req, res, next) {
    pool.db_call(function (connection) {
        connection.query('update user set ? where UID = ?', [req.body, req.params.UID], function (error, results, fields) {
            if (error) {
                console.log('Error --> ' + error);
                res.send({ status: 0, message: "Error in Updation" });
                connection.release();
                return;
            }          
            res.send({ status: 0, message: "User data updated successfully" });          
            connection.release();
        });
    });
};

exports.getUser = function (req, res, next) {
    pool.db_call(function (connection) {
        connection.query('Select * from user where UID = ?', [req.params.UID], function (error, results, fields) {
            if (error) {
                console.log('Error --> ' + error);
                res.send({ status: 0, message: "Error in Registration" });
                connection.release();
                return;
            }          
                res.send({ status: 1, body : results});          
            connection.release();
        });
    });
};