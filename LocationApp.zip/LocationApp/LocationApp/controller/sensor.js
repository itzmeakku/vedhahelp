﻿var pool = require("../DB/connection");


exports.getAllSensors = function (req, res, next) {
    pool.db_call(function (connection) {
        connection.query('Select * from sensor', [req.body], function (error, results, fields) {
            if (error) {
                console.log('Error --> ' + error);
                res.send({ status: 0, message: "Error in Loading sensor data" });
                connection.release();
                return;
            }
            res.send({ status: 1, body: results });
            connection.release();
        });
    });
};

exports.addSensor = function (req, res, next) {
    pool.db_call(function (connection) {
        connection.query(' Insert into sensor set ?', [req.body], function (error, results, fields) {
            if (error) {
                if (error.code == 'ER_DUP_ENTRY') {
                    res.send({ status: 0, message: "SENSORID already exists" });
                    connection.release();
                    return;
                }
                console.log('Error --> ' + error);
                res.send({ status: 0, message: "Error in adding sensor data" });
                connection.release();
                return;
            }
            res.send({ status: 1, message: "Sensor data added successfully" });
            connection.release();
        });
    });
};
exports.updateSensor = function (req, res, next) {
    pool.db_call(function (connection) {
        connection.query('update sensor set ? where SENSORID = ?', [req.body, req.params.ID], function (error, results, fields) {
            if (error) {
                console.log('Error --> ' + error);
                res.send({ status: 0, message: "Error in updating Sensor data" });
                connection.release();
                return;
            }
            res.send({ status: 1, message: "Sensor data updated successfully" });
            connection.release();
        });
    });
};
exports.getSensor = function (req, res, next) {
    pool.db_call(function (connection) {
        connection.query('Select * from sensor where SENSORID = ?', [req.params.ID], function (error, results, fields) {
            if (error) {
                console.log('Error --> ' + error);
                res.send({ status: 0, message: "Error in loading Sensor data" });
                connection.release();
                return;
            }
            res.send({ status: 1, body: results });
            connection.release();
        });
    });
};
exports.deleteSensor = function (req, res, next) {
    pool.db_call(function (connection) {
        connection.query('delete from sensor where SENSORID = ? ', [req.params.ID], function (error, results, fields) {
            if (error) {
                console.log('Error --> ' + error);
                res.send({ status: 0, message: "Error in Deleting Sensor data" });
                connection.release();
                return;
            }
            res.send({ status: 1, message: "Sensor data deleted successfully" });
            connection.release();
        });
    });
};